package pt1;

public interface Interface {
	
	public int computeTax(int amount);
	public Employee weeklySalary(Employee income);
	public Employee fortnightSalary(Employee income);
	public Employee computeKiwiSaver(Employee kiwiOption);
	public void setObj(Interface obj);
	

}
