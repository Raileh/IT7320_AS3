package exercise;

public interface ICompute {
	public int multiply (int x, int y);
	public int squareVar (int x);
	public void setObj (ICompute obj);
	
}
